package Respostas;

import java.util.Scanner;

public class R4questão8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in); 
		
		int[] v = new int[16];
		

		for (int i = 0; i < 16; i++) {
		    System.out.println("Digite o valor da posição " + i + ": ");
		    v[i] = sc.nextInt();
		}

		
		for (int i = 0; i < 8; i++) {
		    int temp = v[i];
		    v[i] = v[i + 8];
		    v[i + 8] = temp;
		}

	
		System.out.println("Vetor após troca:");
		for (int i = 0; i < 16; i++) {
		    System.out.print(v[i] + " ");
		}
		

	}

}
