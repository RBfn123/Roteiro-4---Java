package Respostas;

import java.util.Scanner;

public class R4Questão3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		
		int numero = 0; 
		int soma = 0;
		int contagem = 0;
		int media = 0; 
		
		
		for (int i = 1; i <= 10; i++) {
			System.out.println("digite um numero: "); 
			 numero = sc.nextInt();
			 
		if (numero % 3 == 0 ) {
			soma = soma + numero;
			contagem = contagem + 1; 
		 
		}
		
			
		}
		
			media = soma / contagem; 
			System.out.println("Media: " + media);
		}
		}
		

	


