package Respostas;

import java.util.Scanner;

public class R4questão4 {
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 

	
	System.out.println("digite o voto: ");
	int voto = sc.nextInt();
	
	if (voto == 1) {
		System.out.println("voto para candidato 1");
		}
	else if (voto == 2) {
		System.out.println("voto para candidato 2");
	}
	else if (voto == 3) {
		System.out.println("voto em branco");
	}
	else {
		System.out.println("voto nulo");
	}
		

	}

}
