package Respostas;

import java.util.Scanner;

public class R4questão7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		
		int menor18 = 0;

		int somaIdadeMulheres = 0;
		int qtdMulheres = 0;

		int homensTotal = 0;
		int homensAcima22 = 0;
		
		for (int i = 1; i <= 8; i++) {
		    System.out.println("Aluno " + i);

		    System.out.println("Digite a idade: ");
		    int idade = sc.nextInt();

		    System.out.println("Digite o sexo (M/F): ");
		    char sexo = sc.next().toUpperCase().charAt(0);

		    
		    if (idade < 18) {
		        menor18++;
		    }

		   if (sexo == 'F') {
		        somaIdadeMulheres += idade;
		        qtdMulheres++;
		    }

		   if (sexo == 'M') {
		        homensTotal++;

		   if (idade > 22) {
		       homensAcima22++;
		        }
		    }
		}

		
		double mediaMulheres = 0;
		if (qtdMulheres > 0) {
		    mediaMulheres = (double) somaIdadeMulheres / qtdMulheres;
		}

		
		double percHomens = 0;
		if (homensTotal > 0) {
		    percHomens = (homensAcima22 * 100.0) / homensTotal;
		}

	
		System.out.println("Menores de 18: " + menor18);
		System.out.println("Media de idade das mulheres: " + mediaMulheres);
		System.out.println("Percentual de homens acima de 22: " + percHomens + "%");

	}

}
