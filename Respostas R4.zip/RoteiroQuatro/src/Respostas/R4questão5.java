package Respostas;

import java.util.Scanner;

public class R4questão5 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in); 
	
	int cand1 = 0;
	int cand2 = 0;
	int branco = 0;
	int nulo = 0; 
	
	for (int i = 1; i <= 12; i++) {
		System.out.println("Digite o voto: " + i + ": "); 
	int voto = sc.nextInt(); 
	
	if (voto == 1) {
		cand1++;
		}
	else if (voto == 2) {
		cand2++;
	}
	else if (voto == 3) {
		branco++;
	}
	else {
		nulo++; 
	}
		}
 int total = 12; 
 
 double percBranco = (branco * 100.0) / total;
 double percNulo = (nulo * 100.0) / total;
 
 System.out.println("Candidato 1: " + cand1 + " votos"); 
 System.out.println("Candidato 2: " + cand2 + " votos");
 System.out.println("Brancos : " + branco + " votos"); 
 System.out.println("Nulos : " + nulo + " votos"); 
 

 System.out.println("Percentual de brancos: " + percBranco + "%"); 
 System.out.println("Percentual de nulos: " + percNulo + "%");
	}

}
