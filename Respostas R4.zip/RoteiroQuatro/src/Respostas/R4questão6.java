package Respostas;

import java.util.Scanner;

public class R4questão6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		
		int contra = 0;
		int homensafavor = 0; 
		
		for (int i = 1; i <= 8; i++) {
			System.out.println("pessoa " + i); 
			
			System.out.println("Digite o sexo (M/F): ");
	   char sexo = sc.next().toUpperCase().charAt(0);
	   
	    System.out.println("Digite o voto (1=contra, 2=a favor, 3=nao sabe): ");
	    int voto = sc.nextInt();
	    
	    if (voto == 1) {
	        contra++;
	    }

	    if (sexo == 'M' && voto == 2) {
	        homensafavor++;
	    }
	}

	
	int total = 8;

	double percHomensFavor = (homensafavor * 100.0) / total;

	
	System.out.println("Pessoas contra: " + contra);
	System.out.println("Percentual de homens a favor: " + percHomensFavor + "%");
		}
	}

